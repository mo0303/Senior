<?php 
 
 $dbHost =  "localhost";
 $dbUsername = "id20470333_root";
 $dbPassword = ")G79_}MMhBT\?*Vj";
 $dbName = "id20470333_vmproject";

 $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

 if ($db->connect_error){
    die("Connection failed: ". $db->connect_error);

 }
?>