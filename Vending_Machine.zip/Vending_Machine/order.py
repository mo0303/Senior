#!/usr/bin/env python 
import sys, time
#import RPi.GPIO as GPIO
#GPIO.setmode(GPIO.BOARD)
#coinpin = 16    # GPIO @ connected on 16 pin / Ref RasPi4B.
#GPIO.setup(coinpin, GPIO.IN)    #Set GPIO pin Input.

order = ' '.join(sys.argv[1:])

class Control_servo:
  def Servo(self, order):
    self.order = order
    print("Servo {} ON!".format(self.order)) 
    
s = Control_servo()
s.Servo(order)
