<?php

if (isset($_POST['msg'])) {
    $myfile = fopen("data.txt", "a") or die("Unable to open file!");
    $msg = $_POST['msg'];

    echo $msg ;
    fwrite($myfile ,$msg." ". "฿"."\n");
    fclose($myfile);
}
else {
    echo "Data not received <br/>";
}

$myfile = fopen("data.txt", "r");

while(!feof($myfile)) {
    echo fgets($myfile). "<br/>";
}
fclose($myfile);

?>
