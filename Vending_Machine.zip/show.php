<?php
echo getcwd();
?>
